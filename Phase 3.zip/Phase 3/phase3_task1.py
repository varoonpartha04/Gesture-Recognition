from pandas import DataFrame
import numpy as np
from task3 import process_input
from os import listdir
from os.path import isfile, join
from readAndWriteData import read_json

def sim_graph_from_sim_max(similarity_matrix, gestures_list, k_value):
    pd = {"gestureId": gestures_list}
    idx = 0
    for d in similarity_matrix:
        pd[gestures_list[idx]] = d
        idx += 1

    df = DataFrame(pd)
    df = df.set_index("gestureId")
    sim_graph = np.empty((0, len(similarity_matrix)))
    # sim_matrix = np.empty((0, len(eucl_dist)))
    for row in similarity_matrix:
        k_largest = np.argsort(-np.array(row))[1:k_value + 1]
        sim_graph_row = [d if i in k_largest else 0 for i, d in enumerate(row)]
        sim_graph = np.append(sim_graph, np.array([sim_graph_row]), axis=0)

    row_sums = sim_graph.sum(axis=1)
    sim_graph = sim_graph / row_sums[:, np.newaxis]
    return sim_graph

def ppr(sim_graph, gestures_list, query_gestures, max_iter=500, alpha=0.85):
    sim_graph = sim_graph.T
    teleport_matrix = np.array([0 if img not in query_gestures else 1 for img in gestures_list]).reshape(len(gestures_list), 1)
    teleport_matrix = teleport_matrix / len(query_gestures)
    uq_new = teleport_matrix
    uq_old = np.array((len(gestures_list), 1))
    iter = 0
    while iter < max_iter and not np.array_equal(uq_new, uq_old):
        uq_old = uq_new.copy()
        uq_new = alpha * np.matmul(sim_graph, uq_old) + (1 - alpha) * teleport_matrix
        iter += 1
    print("Iterations: {}".format(iter))
    uq_new = uq_new.ravel()
    a = (-uq_new).argsort()
    result = []
    rank = 1
    for i in a:
        res = {"gestureId": gestures_list[i], "score": uq_new[i], "rank": rank}
        result.append(res)
        rank += 1
    return result


def main():
    k = int(input("enter the no of components ")) # no of components
    n=1
    m=1
    print(k,n,m)
    method=2 # 2 -> pca
    vector_model = "1" # 1-> svd, 2-> nmf
    semantic_features = ['LT-'+str(1+i) for i in range(k)]
    process_input(method, vector_model, k, semantic_features)
    similarity_matrix = read_json("Outputs/similaritymatrix_pca.json")
    
    mypath = "3_class_gesture_data/W"
    gestures_list = [f for f in listdir(mypath) if isfile(join(mypath, f))]
     
    similarity_graph = sim_graph_from_sim_max(similarity_matrix, gestures_list, k)
    # n = input() # different user specified inputs
    # m = input() # m -> no of most dominant gestures
    print(similarity_graph)
if __name__ == "__main__":
    main()